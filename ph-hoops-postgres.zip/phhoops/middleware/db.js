const fs = require('fs');
const path = require('path');
const DB_PATH = path.join(__dirname, '../data/db.json');

function read() {
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function write(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function nextId(type) {
  const db = read();
  const id = db.nextIds[type];
  db.nextIds[type]++;
  write(db);
  return id;
}

module.exports = { read, write, nextId };
