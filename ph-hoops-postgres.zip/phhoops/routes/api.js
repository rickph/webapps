const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const PDFDocument = require('pdfkit');
const { read, write, nextId } = require('../middleware/db');
const { authMiddleware, SECRET } = require('../middleware/auth');

// ── AUTH ──────────────────────────────────────────────────────────────────────
router.post('/auth/login', (req, res) => {
  const { leagueId, adminCode } = req.body;
  const db = read();
  const league = db.leagues.find(l => l.id === Number(leagueId));
  if (!league || league.adminCode !== adminCode)
    return res.status(401).json({ error: 'Invalid league or access code' });
  const token = jwt.sign({ leagueId: league.id, leagueName: league.name }, SECRET, { expiresIn: '12h' });
  res.json({ token, league });
});

// ── PUBLIC: LEAGUES ───────────────────────────────────────────────────────────
router.get('/leagues', (req, res) => {
  const db = read();
  const leagues = db.leagues.filter(l => l.isPublic).map(l => ({
    ...l,
    adminCode: undefined,
    teamCount: db.teams.filter(t => t.leagueId === l.id).length,
    playerCount: db.players.filter(p => p.leagueId === l.id).length,
    gamesPlayed: db.games.filter(g => g.leagueId === l.id && g.status === 'final').length,
  }));
  res.json(leagues);
});

router.get('/leagues/:id', (req, res) => {
  const db = read();
  const league = db.leagues.find(l => l.id === Number(req.params.id) && l.isPublic);
  if (!league) return res.status(404).json({ error: 'League not found' });
  res.json({ ...league, adminCode: undefined });
});

// ── PUBLIC: TEAMS ─────────────────────────────────────────────────────────────
router.get('/leagues/:id/teams', (req, res) => {
  const db = read();
  res.json(db.teams.filter(t => t.leagueId === Number(req.params.id))
    .sort((a, b) => b.wins - a.wins));
});

// ── PUBLIC: PLAYERS ───────────────────────────────────────────────────────────
router.get('/leagues/:id/players', (req, res) => {
  const db = read();
  res.json(db.players.filter(p => p.leagueId === Number(req.params.id))
    .sort((a, b) => b.pts - a.pts));
});

// ── PUBLIC: GAMES ─────────────────────────────────────────────────────────────
router.get('/leagues/:id/games', (req, res) => {
  const db = read();
  res.json(db.games.filter(g => g.leagueId === Number(req.params.id)));
});

// ── ADMIN: LEAGUES CRUD ───────────────────────────────────────────────────────
router.post('/admin/leagues', authMiddleware, (req, res) => {
  const db = read();
  const league = { id: nextId('league'), ...req.body, isPublic: true, createdAt: new Date().toISOString().split('T')[0] };
  db.leagues.push(league);
  write(db);
  res.json(league);
});

router.put('/admin/leagues/:id', authMiddleware, (req, res) => {
  const db = read();
  const idx = db.leagues.findIndex(l => l.id === Number(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  db.leagues[idx] = { ...db.leagues[idx], ...req.body, id: db.leagues[idx].id };
  write(db);
  res.json(db.leagues[idx]);
});

// ── ADMIN: TEAMS CRUD ─────────────────────────────────────────────────────────
router.post('/admin/teams', authMiddleware, (req, res) => {
  const db = read();
  const team = { id: nextId('team'), wins: 0, losses: 0, ...req.body, leagueId: req.admin.leagueId };
  db.teams.push(team);
  write(db);
  res.json(team);
});

router.put('/admin/teams/:id', authMiddleware, (req, res) => {
  const db = read();
  const idx = db.teams.findIndex(t => t.id === Number(req.params.id) && t.leagueId === req.admin.leagueId);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  db.teams[idx] = { ...db.teams[idx], ...req.body, id: db.teams[idx].id };
  write(db);
  res.json(db.teams[idx]);
});

router.delete('/admin/teams/:id', authMiddleware, (req, res) => {
  const db = read();
  db.teams = db.teams.filter(t => !(t.id === Number(req.params.id) && t.leagueId === req.admin.leagueId));
  db.players = db.players.filter(p => p.teamId !== Number(req.params.id));
  write(db);
  res.json({ ok: true });
});

// ── ADMIN: PLAYERS CRUD ───────────────────────────────────────────────────────
router.post('/admin/players', authMiddleware, (req, res) => {
  const db = read();
  const player = { id: nextId('player'), ...req.body, leagueId: req.admin.leagueId };
  db.players.push(player);
  write(db);
  res.json(player);
});

router.put('/admin/players/:id', authMiddleware, (req, res) => {
  const db = read();
  const idx = db.players.findIndex(p => p.id === Number(req.params.id) && p.leagueId === req.admin.leagueId);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  db.players[idx] = { ...db.players[idx], ...req.body, id: db.players[idx].id };
  write(db);
  res.json(db.players[idx]);
});

router.delete('/admin/players/:id', authMiddleware, (req, res) => {
  const db = read();
  db.players = db.players.filter(p => !(p.id === Number(req.params.id) && p.leagueId === req.admin.leagueId));
  write(db);
  res.json({ ok: true });
});

// ── ADMIN: GAMES CRUD ─────────────────────────────────────────────────────────
router.post('/admin/games', authMiddleware, (req, res) => {
  const db = read();
  const game = { id: nextId('game'), ...req.body, leagueId: req.admin.leagueId };
  db.games.push(game);
  write(db);
  res.json(game);
});

router.put('/admin/games/:id', authMiddleware, (req, res) => {
  const db = read();
  const idx = db.games.findIndex(g => g.id === Number(req.params.id) && g.leagueId === req.admin.leagueId);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  db.games[idx] = { ...db.games[idx], ...req.body, id: db.games[idx].id };
  write(db);
  res.json(db.games[idx]);
});

router.delete('/admin/games/:id', authMiddleware, (req, res) => {
  const db = read();
  db.games = db.games.filter(g => !(g.id === Number(req.params.id) && g.leagueId === req.admin.leagueId));
  write(db);
  res.json({ ok: true });
});

// ── ADMIN: LIVE SCORE ─────────────────────────────────────────────────────────
router.post('/admin/games/:id/finalize', authMiddleware, (req, res) => {
  const db = read();
  const { homeScore, awayScore } = req.body;
  const gIdx = db.games.findIndex(g => g.id === Number(req.params.id) && g.leagueId === req.admin.leagueId);
  if (gIdx === -1) return res.status(404).json({ error: 'Not found' });

  const game = db.games[gIdx];
  db.games[gIdx] = { ...game, homeScore, awayScore, status: 'final' };

  // Update standings
  const winnerId = homeScore > awayScore ? game.homeTeamId : game.awayTeamId;
  const loserId  = homeScore > awayScore ? game.awayTeamId : game.homeTeamId;
  db.teams = db.teams.map(t => {
    if (t.id === winnerId) return { ...t, wins: t.wins + 1 };
    if (t.id === loserId)  return { ...t, losses: t.losses + 1 };
    return t;
  });
  write(db);
  res.json({ ok: true, game: db.games[gIdx] });
});

// ── ADMIN: BRACKET GENERATOR ──────────────────────────────────────────────────
router.get('/admin/bracket/:leagueId', authMiddleware, (req, res) => {
  const db = read();
  const teams = db.teams
    .filter(t => t.leagueId === Number(req.params.leagueId))
    .sort((a, b) => b.wins - a.wins);

  // Single elimination bracket
  let seeds = [...teams];
  // Pad to next power of 2
  const size = Math.pow(2, Math.ceil(Math.log2(Math.max(seeds.length, 2))));
  while (seeds.length < size) seeds.push(null); // BYE

  // Build round 1 matchups (1v8, 2v7, etc.)
  const matchups = [];
  for (let i = 0; i < size / 2; i++) {
    matchups.push({ seed1: i + 1, team1: seeds[i], seed2: size - i, team2: seeds[size - 1 - i] });
  }

  const rounds = Math.log2(size);
  res.json({ teams, matchups, totalRounds: rounds, size });
});

// ── PDF: STAT SHEET ───────────────────────────────────────────────────────────
router.get('/pdf/league/:id/stats', (req, res) => {
  const db = read();
  const league = db.leagues.find(l => l.id === Number(req.params.id));
  if (!league) return res.status(404).json({ error: 'Not found' });

  const teams   = db.teams.filter(t => t.leagueId === league.id).sort((a, b) => b.wins - a.wins);
  const players = db.players.filter(p => p.leagueId === league.id).sort((a, b) => b.pts - a.pts);

  const doc = new PDFDocument({ margin: 40, size: 'A4' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${league.name.replace(/\s+/g, '_')}_stats.pdf"`);
  doc.pipe(res);

  // Header
  doc.rect(0, 0, doc.page.width, 70).fill('#0a0a0f');
  doc.fill('#ff6b35').fontSize(22).font('Helvetica-Bold').text('PH HOOPS', 40, 15);
  doc.fill('#ffffff').fontSize(11).font('Helvetica').text('LEAGUE STAT SHEET', 40, 42);
  doc.fill('#aaaaaa').fontSize(9).text(`Generated: ${new Date().toLocaleDateString('en-PH')}`, doc.page.width - 160, 42);
  doc.moveDown(3);

  // League Info
  doc.fill('#ff6b35').fontSize(16).font('Helvetica-Bold').text(league.name, 40, 85);
  doc.fill('#888888').fontSize(10).font('Helvetica').text(`${league.level} · ${league.location} · ${league.season}`, 40, 106);

  // Divider
  doc.moveTo(40, 124).lineTo(doc.page.width - 40, 124).strokeColor('#333333').lineWidth(1).stroke();

  // Standings Table
  doc.fill('#ffffff').fontSize(13).font('Helvetica-Bold').text('STANDINGS', 40, 134);

  const tHeaders = ['#', 'Team', 'W', 'L', 'WIN%'];
  const tWidths  = [25, 250, 40, 40, 60];
  let y = 155;

  // Table header
  doc.rect(40, y, doc.page.width - 80, 20).fill('#1a1a2e');
  let x = 40;
  tHeaders.forEach((h, i) => {
    doc.fill('#ff6b35').fontSize(8).font('Helvetica-Bold').text(h, x + 4, y + 6, { width: tWidths[i] });
    x += tWidths[i];
  });
  y += 22;

  teams.forEach((t, i) => {
    if (y > doc.page.height - 100) { doc.addPage(); y = 40; }
    if (i % 2 === 0) doc.rect(40, y, doc.page.width - 80, 18).fill('#0f0f1f');
    x = 40;
    const row = [i + 1, t.name, t.wins, t.losses, `${((t.wins / (t.wins + t.losses || 1)) * 100).toFixed(1)}%`];
    row.forEach((val, j) => {
      doc.fill(j === 1 ? '#ffffff' : j === 2 ? '#00d4aa' : j === 3 ? '#ff4757' : '#cccccc')
         .fontSize(9).font(j === 0 ? 'Helvetica-Bold' : 'Helvetica')
         .text(String(val), x + 4, y + 5, { width: tWidths[j] });
      x += tWidths[j];
    });
    y += 20;
  });

  y += 16;
  if (y > doc.page.height - 150) { doc.addPage(); y = 40; }

  // Player Stats Table
  doc.fill('#ffffff').fontSize(13).font('Helvetica-Bold').text('PLAYER STATISTICS', 40, y);
  y += 20;

  const pHeaders = ['#', 'Player', 'Team', 'POS', 'GP', 'PTS', 'REB', 'AST', 'STL', 'BLK', 'FG%'];
  const pWidths  = [20, 130, 100, 28, 25, 32, 32, 32, 28, 28, 35];

  doc.rect(40, y, doc.page.width - 80, 20).fill('#1a1a2e');
  x = 40;
  pHeaders.forEach((h, i) => {
    doc.fill('#ff6b35').fontSize(7).font('Helvetica-Bold').text(h, x + 2, y + 7, { width: pWidths[i] });
    x += pWidths[i];
  });
  y += 22;

  players.forEach((p, i) => {
    if (y > doc.page.height - 60) { doc.addPage(); y = 40; }
    const team = teams.find(t => t.id === p.teamId);
    if (i % 2 === 0) doc.rect(40, y, doc.page.width - 80, 16).fill('#0f0f1f');
    x = 40;
    const row = [i + 1, p.name, team?.name || '—', p.pos, p.gp, p.pts, p.reb, p.ast, p.stl, p.blk, `${p.fg}%`];
    row.forEach((val, j) => {
      const color = j === 5 ? '#ff6b35' : j === 10 ? '#00d4aa' : j === 1 ? '#ffffff' : '#cccccc';
      doc.fill(color).fontSize(8).font(j <= 1 ? 'Helvetica-Bold' : 'Helvetica')
         .text(String(val), x + 2, y + 4, { width: pWidths[j] });
      x += pWidths[j];
    });
    y += 18;
  });

  // Footer
  doc.fill('#555555').fontSize(8).font('Helvetica').text('PH Hoops League Manager · phhoops.app', 40, doc.page.height - 30);
  doc.end();
});

// ── PDF: PLAYER PROFILE ───────────────────────────────────────────────────────
router.get('/pdf/player/:id', (req, res) => {
  const db = read();
  const player = db.players.find(p => p.id === Number(req.params.id));
  if (!player) return res.status(404).json({ error: 'Not found' });
  const team   = db.teams.find(t => t.id === player.teamId);
  const league = db.leagues.find(l => l.id === player.leagueId);

  const doc = new PDFDocument({ margin: 40, size: 'A4' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${player.name.replace(/\s+/g, '_')}_profile.pdf"`);
  doc.pipe(res);

  // BG header
  doc.rect(0, 0, doc.page.width, 120).fill('#0a0a0f');
  doc.circle(doc.page.width - 80, 60, 55).fill('#1a1a2e');
  doc.fill('#ff6b35').fontSize(10).font('Helvetica-Bold').text('PH HOOPS', 40, 20);
  doc.fill('#ffffff').fontSize(32).font('Helvetica-Bold').text(player.name, 40, 42);
  doc.fill('#aaaaaa').fontSize(11).font('Helvetica').text(`#${player.jersey} · ${player.pos} · ${team?.name || '—'}`, 40, 82);
  doc.fill('#ff6b35').fontSize(72).font('Helvetica-Bold').text(player.jersey, doc.page.width - 104, 28);

  // League
  doc.fill('#cccccc').fontSize(10).font('Helvetica').text(`${league?.name || '—'} · ${league?.season || '—'}`, 40, 135);

  // Stats grid
  const stats = [
    { label: 'PTS', value: player.pts, color: '#ff6b35' },
    { label: 'REB', value: player.reb, color: '#00d4aa' },
    { label: 'AST', value: player.ast, color: '#a78bfa' },
    { label: 'STL', value: player.stl, color: '#f7c948' },
    { label: 'BLK', value: player.blk, color: '#fb5607' },
    { label: 'FG%', value: `${player.fg}%`, color: '#06d6a0' },
  ];

  let sx = 40; const sy = 165;
  const bw = 80, bh = 70;
  stats.forEach((s, i) => {
    if (i === 3) { sx = 40; }
    const by = sy + (i < 3 ? 0 : bh + 10);
    doc.rect(sx, by, bw - 6, bh).fill('#0f0f1f').stroke('#1a1a2e');
    doc.fill(s.color).fontSize(28).font('Helvetica-Bold').text(String(s.value), sx + 6, by + 10, { width: bw - 12, align: 'center' });
    doc.fill('#888888').fontSize(9).font('Helvetica-Bold').text(s.label, sx + 6, by + 48, { width: bw - 12, align: 'center' });
    sx += bw + 4;
  });

  doc.fill('#555555').fontSize(8).text(`Games Played: ${player.gp}`, 40, 320);
  doc.fill('#555555').fontSize(8).font('Helvetica').text('PH Hoops League Manager', 40, doc.page.height - 30);
  doc.end();
});

// ── SUBSCRIPTION CHECK ────────────────────────────────────────────────────────
router.get('/subscription/:leagueId', (req, res) => {
  const db = read();
  const sub = db.subscriptions?.find(s => s.leagueId === Number(req.params.leagueId));
  res.json(sub || { leagueId: Number(req.params.leagueId), plan: 'free', expiresAt: null });
});

module.exports = router;
