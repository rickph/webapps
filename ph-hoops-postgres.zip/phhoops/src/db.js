const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, '../data/db.json');

const DEFAULT_DB = {
  leagues: [
    { id: 1, name: "Brgy. San Roque Basketball Cup", level: "Barangay", location: "San Roque, Marikina City", season: "Summer 2025", status: "ongoing", isPublic: true, adminCode: "SRC2025", createdAt: new Date().toISOString() },
    { id: 2, name: "Marikina City Inter-Barangay League", level: "City/Municipal", location: "Marikina City, Metro Manila", season: "2025 Season", status: "ongoing", isPublic: true, adminCode: "MKN2025", createdAt: new Date().toISOString() },
    { id: 3, name: "Metro Manila Regional Championship", level: "Regional", location: "Metro Manila", season: "2025", status: "upcoming", isPublic: true, adminCode: "MMR2025", createdAt: new Date().toISOString() },
  ],
  teams: [
    { id: 1, leagueId: 1, name: "Purok 1 Ballers", color: "#e63946", wins: 4, losses: 1 },
    { id: 2, leagueId: 1, name: "Sitio Bagong Pag-asa", color: "#457b9d", wins: 3, losses: 2 },
    { id: 3, leagueId: 1, name: "Zone 3 Warriors", color: "#2a9d8f", wins: 2, losses: 3 },
    { id: 4, leagueId: 1, name: "Purok 5 Eagles", color: "#e9c46a", wins: 1, losses: 4 },
    { id: 5, leagueId: 2, name: "Brgy. Concepcion Ballers", color: "#f4a261", wins: 6, losses: 0 },
    { id: 6, leagueId: 2, name: "Brgy. Nangka Knights", color: "#264653", wins: 4, losses: 2 },
    { id: 7, leagueId: 2, name: "Brgy. Tumana Tigers", color: "#e76f51", wins: 3, losses: 3 },
  ],
  players: [
    { id: 1, teamId: 1, leagueId: 1, name: "Mark Reyes", pos: "PG", jersey: 7, gp: 5, pts: 22.4, reb: 4.1, ast: 6.8, stl: 2.2, blk: 0.4, fg: 48.3 },
    { id: 2, teamId: 1, leagueId: 1, name: "Joey Santos", pos: "SF", jersey: 23, gp: 5, pts: 18.6, reb: 7.3, ast: 2.1, stl: 1.4, blk: 1.2, fg: 52.1 },
    { id: 3, teamId: 2, leagueId: 1, name: "Gio dela Cruz", pos: "C", jersey: 0, gp: 5, pts: 15.2, reb: 11.4, ast: 1.0, stl: 0.8, blk: 2.6, fg: 61.0 },
    { id: 4, teamId: 3, leagueId: 1, name: "Andrei Bautista", pos: "SG", jersey: 3, gp: 5, pts: 20.0, reb: 3.5, ast: 4.2, stl: 2.8, blk: 0.2, fg: 44.7 },
    { id: 5, teamId: 5, leagueId: 2, name: "Renz Villanueva", pos: "PF", jersey: 32, gp: 6, pts: 24.1, reb: 10.2, ast: 2.4, stl: 1.1, blk: 1.8, fg: 55.3 },
    { id: 6, teamId: 6, leagueId: 2, name: "Kuya Bob Lim", pos: "PG", jersey: 5, gp: 6, pts: 17.8, reb: 3.0, ast: 9.1, stl: 3.0, blk: 0.1, fg: 41.2 },
  ],
  games: [
    { id: 1, leagueId: 1, homeTeamId: 1, awayTeamId: 2, homeScore: 78, awayScore: 65, date: "Apr 20, 2025", venue: "Brgy. San Roque Court", status: "final" },
    { id: 2, leagueId: 1, homeTeamId: 3, awayTeamId: 4, homeScore: 55, awayScore: 70, date: "Apr 21, 2025", venue: "Purok 5 Mini Court", status: "final" },
    { id: 3, leagueId: 1, homeTeamId: 1, awayTeamId: 3, homeScore: 0, awayScore: 0, date: "Apr 27, 2025", venue: "Brgy. San Roque Court", status: "upcoming" },
    { id: 4, leagueId: 2, homeTeamId: 5, awayTeamId: 6, homeScore: 88, awayScore: 72, date: "Apr 19, 2025", venue: "Marikina Sports Complex", status: "final" },
  ],
  brackets: [],
  nextId: { league: 4, team: 8, player: 7, game: 5, bracket: 1 }
};

function load() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
      fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2));
    }
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch (e) {
    return JSON.parse(JSON.stringify(DEFAULT_DB));
  }
}

function save(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

function uid(data, type) {
  const id = data.nextId[type];
  data.nextId[type]++;
  return id;
}

module.exports = { load, save, uid };
